# rss-feeds
A collection of my RSS feeds.

https://sourceforge.net/projects/rssowl/

1. Install RSSOwl with a 32 bit JRE.
2. Tools -> Find More Feeds -> Import feeds.